<?php
require_once 'functions.php';
page_header('Library Reports');
$borrowed=$pdo->query("SELECT COUNT(*) FROM borrow_transactions WHERE status='Borrowed'")->fetchColumn();
$returned=$pdo->query("SELECT COUNT(*) FROM borrow_transactions WHERE status='Returned'")->fetchColumn();
$overdue=$pdo->query("SELECT COUNT(*) FROM borrow_transactions WHERE status='Borrowed' AND due_date<CURDATE()")->fetchColumn();
echo '<section class="stats"><div class="stat"><span>Borrowed</span><strong>'.e($borrowed).'</strong></div><div class="stat"><span>Returned</span><strong>'.e($returned).'</strong></div><div class="stat"><span>Overdue</span><strong>'.e($overdue).'</strong></div></section>';
$rows=$pdo->query("SELECT b.title,COUNT(t.transaction_id) borrow_count FROM books b LEFT JOIN borrow_transactions t ON t.book_id=b.book_id GROUP BY b.book_id ORDER BY borrow_count DESC,b.title")->fetchAll();
echo '<section class="panel"><h2>Most borrowed books</h2><div class="table-wrap"><table><tr><th>Book</th><th>Number of borrowings</th></tr>';foreach($rows as $r)echo '<tr><td>'.e($r['title']).'</td><td>'.e($r['borrow_count']).'</td></tr>';echo '</table></div></section>';
$over=$pdo->query("SELECT t.transaction_id,b.title,br.full_name,t.borrow_date,t.due_date,DATEDIFF(CURDATE(),t.due_date) days_overdue FROM borrow_transactions t JOIN books b ON b.book_id=t.book_id JOIN borrowers br ON br.borrower_id=t.borrower_id WHERE t.status='Borrowed' AND t.due_date<CURDATE() ORDER BY t.due_date")->fetchAll();
echo '<section class="panel"><h2>Overdue report</h2><div class="table-wrap"><table><tr><th>ID</th><th>Book</th><th>Borrower</th><th>Due date</th><th>Days overdue</th></tr>';foreach($over as $r)echo '<tr><td>'.e($r['transaction_id']).'</td><td>'.e($r['title']).'</td><td>'.e($r['full_name']).'</td><td>'.e($r['due_date']).'</td><td>'.e($r['days_overdue']).'</td></tr>';if(!$over)echo '<tr><td colspan="5">No overdue books.</td></tr>';echo '</table></div></section>';
echo '<section class="panel"><h2>SQL concepts used</h2><p>JOIN, COUNT, GROUP BY, ORDER BY, DATEDIFF, prepared statements, and database transactions.</p></section>';
page_footer();
