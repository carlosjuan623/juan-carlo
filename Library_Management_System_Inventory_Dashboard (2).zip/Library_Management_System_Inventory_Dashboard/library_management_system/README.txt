LIBRARY MANAGEMENT SYSTEM
PHP + MySQL + HTML + CSS + JavaScript

REQUIREMENTS
- XAMPP (Apache and MySQL)
- PHP 8.0+ recommended
- MySQL / MariaDB
- Web browser

INSTALLATION
1. Extract the folder "library_management_system" into:
   C:\xampp\htdocs\
2. Open XAMPP Control Panel and start Apache and MySQL.
3. Open http://localhost/phpmyadmin
4. Import database.sql using the Import tab.
   This creates library_db and its six tables.
5. Check config.php. Default XAMPP MySQL settings are:
   host = localhost, username = root, password = blank.
   Change $dbpass if your MySQL root account has a password.
6. Open http://localhost/library_management_system/setup.php
7. Create your first administrator. Use a password of at least 8 characters.
8. DELETE setup.php after creating the administrator.
9. Open http://localhost/library_management_system/login.php and sign in.

FEATURES
- Admin login with password hashing
- Dashboard statistics and overdue list
- Category CRUD
- Book CRUD and search
- Borrower CRUD and search
- Borrow transactions with stock checking
- Return transactions with book-stock update
- Reports: borrowed, returned, overdue, and most borrowed books
- Prepared SQL statements, foreign keys, CSRF token checks, and transaction handling

DATABASE TABLES
1. users
2. categories
3. books
4. borrowers
5. borrow_transactions
6. returns

IMPORTANT NOTES
- This is a classroom starter project. Test it locally before presenting.
- Books returned in Good condition increase available copies.
- Damaged or Lost books do not increase available copies automatically.
- Keep setup.php deleted after initial setup.
- For a real deployment, use HTTPS, least-privilege database credentials,
  stronger server configuration, and regular off-site backups.

BACKUP
In phpMyAdmin, select library_db > Export > Quick > SQL > Export.
RESTORE
In phpMyAdmin, create/select library_db and use Import to import the saved .sql file.


UPDATED INVENTORY-STYLE DASHBOARD
The main dashboard now shows book title count, total copies, available copies, borrowed copies, and low-stock titles. It includes a searchable and filterable inventory table with category and stock-status filters. Low stock is defined as 2 or fewer available copies. Use the Manage link to edit a book and Add Book to register a new title.
