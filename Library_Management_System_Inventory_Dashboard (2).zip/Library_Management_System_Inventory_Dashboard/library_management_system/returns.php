<?php
require_once 'functions.php';
verify_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $id=(int)$_POST['transaction_id'];$date=post_value('return_date');$condition=post_value('book_condition');
  $pdo->beginTransaction();
  $s=$pdo->prepare("SELECT * FROM borrow_transactions WHERE transaction_id=? AND status='Borrowed' FOR UPDATE");$s->execute([$id]);$t=$s->fetch();
  if(!$t)throw new Exception('Transaction not found or book already returned.');
  $s=$pdo->prepare("INSERT INTO returns(transaction_id,return_date,book_condition,received_by,notes) VALUES(?,?,?,?,?)");
  $s->execute([$id,$date,$condition,$_SESSION['user_id'],post_value('notes')?:null]);
  $s=$pdo->prepare("UPDATE borrow_transactions SET status='Returned' WHERE transaction_id=?");$s->execute([$id]);
  if($condition==='Good'){$s=$pdo->prepare("UPDATE books SET available_copies=LEAST(total_copies,available_copies+1) WHERE book_id=?");$s->execute([$t['book_id']]);}
  $pdo->commit();flash('Book return recorded.');
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash($e->getMessage(),'error');}
 redirect('returns.php');
}
page_header('Book Returns');
$pending=$pdo->query("SELECT t.transaction_id,b.title,br.full_name,t.due_date FROM borrow_transactions t JOIN books b ON b.book_id=t.book_id JOIN borrowers br ON br.borrower_id=t.borrower_id WHERE t.status='Borrowed' ORDER BY t.due_date")->fetchAll();
echo '<section class="panel"><h2>Record a return</h2>';
if(!$pending)echo '<p>There are no borrowed books waiting for return.</p>';
else{echo '<form method="post" class="form-grid"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><label>Borrowed transaction<select name="transaction_id" required>';foreach($pending as $p)echo '<option value="'.e($p['transaction_id']).'">#'.e($p['transaction_id']).' · '.e($p['title']).' · '.e($p['full_name']).' · Due '.e($p['due_date']).'</option>';echo '</select></label><label>Return date<input type="date" name="return_date" value="'.date('Y-m-d').'" required></label><label>Book condition<select name="book_condition"><option>Good</option><option>Damaged</option><option>Lost</option></select></label><label>Notes<input name="notes"></label><div><button>Save return</button></div></form>';}
echo '</section>';
$rows=$pdo->query("SELECT r.*,t.transaction_id,b.title,br.full_name FROM returns r JOIN borrow_transactions t ON t.transaction_id=r.transaction_id JOIN books b ON b.book_id=t.book_id JOIN borrowers br ON br.borrower_id=t.borrower_id ORDER BY r.return_id DESC")->fetchAll();
echo '<section class="panel"><h2>Return history</h2><div class="table-wrap"><table><tr><th>Transaction</th><th>Book</th><th>Borrower</th><th>Return date</th><th>Condition</th><th>Notes</th></tr>';
foreach($rows as $r)echo '<tr><td>'.e($r['transaction_id']).'</td><td>'.e($r['title']).'</td><td>'.e($r['full_name']).'</td><td>'.e($r['return_date']).'</td><td>'.e($r['book_condition']).'</td><td>'.e($r['notes']).'</td></tr>';
echo '</table></div></section>';page_footer();
