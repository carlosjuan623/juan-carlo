CREATE DATABASE IF NOT EXISTS library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_db;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','librarian') NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
  book_id INT AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(30) NULL UNIQUE,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(120) NOT NULL,
  publisher VARCHAR(120) NULL,
  publish_year YEAR NULL,
  category_id INT NOT NULL,
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_books_category FOREIGN KEY (category_id)
    REFERENCES categories(category_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_book_copies CHECK (total_copies >= 0 AND available_copies >= 0 AND available_copies <= total_copies)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS borrowers (
  borrower_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NULL,
  phone VARCHAR(30) NULL,
  address VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS borrow_transactions (
  transaction_id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  borrower_id INT NOT NULL,
  borrowed_by INT NOT NULL,
  borrow_date DATE NOT NULL,
  due_date DATE NOT NULL,
  status ENUM('Borrowed','Returned') NOT NULL DEFAULT 'Borrowed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_transaction_book FOREIGN KEY (book_id)
    REFERENCES books(book_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_transaction_borrower FOREIGN KEY (borrower_id)
    REFERENCES borrowers(borrower_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_transaction_user FOREIGN KEY (borrowed_by)
    REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS returns (
  return_id INT AUTO_INCREMENT PRIMARY KEY,
  transaction_id INT NOT NULL UNIQUE,
  return_date DATE NOT NULL,
  book_condition ENUM('Good','Damaged','Lost') NOT NULL DEFAULT 'Good',
  received_by INT NOT NULL,
  notes VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_return_transaction FOREIGN KEY (transaction_id)
    REFERENCES borrow_transactions(transaction_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_return_user FOREIGN KEY (received_by)
    REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

INSERT IGNORE INTO categories (category_name, description) VALUES
('Fiction','Novels and imaginative stories'),
('Non-Fiction','Informational and factual books'),
('Science','Science and technology books'),
('History','Historical books'),
('Reference','Dictionaries, encyclopedias, and references');

-- Create the first administrator through setup.php so the password is securely hashed.
