<?php
require_once 'functions.php';
verify_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(($_POST['action']??'')==='save'){
  $id=(int)($_POST['borrower_id']??0);$data=[post_value('full_name'),post_value('email')?:null,post_value('phone')?:null,post_value('address')?:null];
  if($id){$s=$pdo->prepare("UPDATE borrowers SET full_name=?,email=?,phone=?,address=? WHERE borrower_id=?");$s->execute([...$data,$id]);flash('Borrower updated.');}
  else{$s=$pdo->prepare("INSERT INTO borrowers(full_name,email,phone,address) VALUES(?,?,?,?)");$s->execute($data);flash('Borrower added.');}
 }elseif(($_POST['action']??'')==='delete'){
  try{$s=$pdo->prepare("DELETE FROM borrowers WHERE borrower_id=?");$s->execute([(int)$_POST['borrower_id']]);flash('Borrower deleted.');}
  catch(PDOException $e){flash('Borrower has transaction history and cannot be deleted.','error');}
 }
 redirect('borrowers.php');
}
page_header('Borrower Management');$edit=null;
if(isset($_GET['edit'])){$s=$pdo->prepare("SELECT * FROM borrowers WHERE borrower_id=?");$s->execute([(int)$_GET['edit']]);$edit=$s->fetch();}
echo '<section class="panel"><h2>'.($edit?'Edit borrower':'Add borrower').'</h2><form method="post" class="form-grid"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="save"><input type="hidden" name="borrower_id" value="'.e($edit['borrower_id']??'').'">';
foreach(['full_name'=>'Full name','email'=>'Email','phone'=>'Phone','address'=>'Address'] as $k=>$v) echo '<label>'.e($v).'<input name="'.e($k).'" value="'.e($edit[$k]??'').'" '.($k==='full_name'?'required':'').'></label>';
echo '<div><button>Save borrower</button> <a class="button secondary" href="borrowers.php">Clear</a></div></form></section>';
$q=trim($_GET['q']??'');$s=$pdo->prepare("SELECT * FROM borrowers WHERE full_name LIKE ? OR email LIKE ? OR phone LIKE ? ORDER BY full_name");$l="%{$q}%";$s->execute([$l,$l,$l]);$rows=$s->fetchAll();
echo '<section class="panel"><h2>Borrower list</h2><form class="search"><input name="q" placeholder="Search borrower" value="'.e($q).'"><button>Search</button></form><div class="table-wrap"><table><tr><th>Name</th><th>Email</th><th>Phone</th><th>Action</th></tr>';
foreach($rows as $r) echo '<tr><td>'.e($r['full_name']).'</td><td>'.e($r['email']).'</td><td>'.e($r['phone']).'</td><td><a href="borrowers.php?edit='.e($r['borrower_id']).'">Edit</a> <form class="inline" method="post" onsubmit="return confirmDelete()"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="delete"><input type="hidden" name="borrower_id" value="'.e($r['borrower_id']).'"><button class="link danger-text">Delete</button></form></td></tr>';
echo '</table></div></section>';page_footer();
