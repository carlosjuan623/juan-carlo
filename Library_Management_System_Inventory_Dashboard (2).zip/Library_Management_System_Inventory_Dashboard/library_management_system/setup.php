<?php
require_once 'config.php';
$message = '';
$count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0) {
    $name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($name && $username && strlen($password) >= 8) {
        $stmt = $pdo->prepare("INSERT INTO users (full_name, username, password_hash, role) VALUES (?, ?, ?, 'admin')");
        $stmt->execute([$name, $username, password_hash($password, PASSWORD_DEFAULT)]);
        $message = 'Administrator created. Delete setup.php now, then sign in.';
        $count = 1;
    } else {
        $message = 'Complete all fields. Password must be at least 8 characters.';
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Initial Setup</title><link rel="stylesheet" href="assets/style.css"></head><body>
<main class="login-wrap"><section class="panel"><h1>Initial Administrator Setup</h1>
<?php if ($message): ?><div class="alert"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($count === 0): ?>
<p>Create the first administrator account.</p><form method="post">
<label>Full name<input name="full_name" required></label>
<label>Username<input name="username" required></label>
<label>Password (at least 8 characters)<input type="password" name="password" minlength="8" required></label>
<button>Create administrator</button></form>
<?php else: ?><p>An administrator account already exists. Continue to <a href="login.php">login</a>.</p><?php endif; ?>
</section></main></body></html>
