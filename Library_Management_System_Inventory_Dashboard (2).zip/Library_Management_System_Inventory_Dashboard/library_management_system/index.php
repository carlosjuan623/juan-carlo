<?php
require_once 'functions.php';
page_header('Library Inventory Dashboard');

// Inventory summary
$stats = [
    'Book Titles' => (int)$pdo->query("SELECT COUNT(*) FROM books")->fetchColumn(),
    'Total Copies' => (int)$pdo->query("SELECT COALESCE(SUM(total_copies),0) FROM books")->fetchColumn(),
    'Available Copies' => (int)$pdo->query("SELECT COALESCE(SUM(available_copies),0) FROM books")->fetchColumn(),
    'Borrowed Copies' => (int)$pdo->query("SELECT COUNT(*) FROM borrow_transactions WHERE status='Borrowed'")->fetchColumn(),
    'Low Stock Titles' => (int)$pdo->query("SELECT COUNT(*) FROM books WHERE available_copies <= 2")->fetchColumn(),
];

echo '<section class="inventory-stats">';
$icons = ['Book Titles'=>'📚','Total Copies'=>'📦','Available Copies'=>'✅','Borrowed Copies'=>'📖','Low Stock Titles'=>'⚠️'];
foreach ($stats as $label => $value) {
    $class = $label === 'Low Stock Titles' ? 'inventory-stat warning' : 'inventory-stat';
    echo '<article class="'.$class.'"><div class="inventory-stat-top"><span>'.e($label).'</span><span class="inventory-icon">'.$icons[$label].'</span></div><strong>'.number_format($value).'</strong>';
    if ($label === 'Low Stock Titles') echo '<small>Books with 2 or fewer copies available</small>';
    echo '</article>';
}
echo '</section>';

echo '<section class="panel inventory-panel"><div class="section-heading"><div><h2>Book Inventory</h2><p class="muted">Monitor book quantities and availability.</p></div><a class="button" href="books.php">＋ Add Book</a></div>';

$q = trim($_GET['q'] ?? '');
$category = (int)($_GET['category'] ?? 0);
$stock = $_GET['stock'] ?? 'all';
$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)';
    $like = "%{$q}%";
    array_push($params, $like, $like, $like);
}
if ($category > 0) {
    $where[] = 'b.category_id = ?';
    $params[] = $category;
}
if ($stock === 'low') $where[] = 'b.available_copies <= 2';
if ($stock === 'available') $where[] = 'b.available_copies > 2';
$sql = "SELECT b.*, c.category_name, (b.total_copies - b.available_copies) AS borrowed_copies
        FROM books b JOIN categories c ON c.category_id=b.category_id";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY b.title ASC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();
$categories = $pdo->query("SELECT category_id, category_name FROM categories ORDER BY category_name")->fetchAll();

echo '<form method="get" class="inventory-filters">';
echo '<label class="filter-search"><span>Search books</span><input type="search" name="q" placeholder="Search title, author, or ISBN..." value="'.e($q).'"></label>';
echo '<label><span>Category</span><select name="category"><option value="0">All categories</option>';
foreach ($categories as $c) {
    $selected = $category === (int)$c['category_id'] ? ' selected' : '';
    echo '<option value="'.e($c['category_id']).'"'.$selected.'>'.e($c['category_name']).'</option>';
}
echo '</select></label>';
echo '<label><span>Stock status</span><select name="stock">';
foreach (['all'=>'All stock','available'=>'Available (more than 2)','low'=>'Low stock (2 or fewer)'] as $value=>$label) {
    echo '<option value="'.e($value).'"'.($stock===$value?' selected':'').'>'.e($label).'</option>';
}
echo '</select></label><button type="submit">Filter</button><a class="button secondary" href="index.php">Reset</a></form>';

echo '<div class="table-wrap"><table class="inventory-table"><thead><tr><th>Book</th><th>Category</th><th>Total copies</th><th>Available</th><th>Borrowed</th><th>Stock status</th><th>Action</th></tr></thead><tbody>';
if (!$books) {
    echo '<tr><td colspan="7" class="empty-state">No books found. Add a book or change your filters.</td></tr>';
} else {
    foreach ($books as $b) {
        $low = (int)$b['available_copies'] <= 2;
        $status = $low ? '<span class="stock-badge low">Low stock</span>' : '<span class="stock-badge good">In stock</span>';
        $total = max(1, (int)$b['total_copies']);
        $percent = min(100, (int)round(((int)$b['available_copies'] / $total) * 100));
        echo '<tr>';
        echo '<td><strong>'.e($b['title']).'</strong><small class="book-author">'.e($b['author']).'</small></td>';
        echo '<td>'.e($b['category_name']).'</td>';
        echo '<td>'.number_format((int)$b['total_copies']).'</td>';
        echo '<td><strong>'.number_format((int)$b['available_copies']).'</strong><div class="stock-meter"><span style="width:'.$percent.'%"></span></div></td>';
        echo '<td>'.number_format((int)$b['borrowed_copies']).'</td>';
        echo '<td>'.$status.'</td>';
        echo '<td><a class="table-action" href="books.php?edit='.e($b['book_id']).'">Manage</a></td>';
        echo '</tr>';
    }
}
echo '</tbody></table></div><p class="table-footnote">Showing '.count($books).' book title(s). Low stock means 2 or fewer available copies.</p></section>';

echo '<section class="panel dashboard-shortcuts"><div class="section-heading"><div><h2>Quick actions</h2><p class="muted">Common library tasks</p></div></div><div class="actions"><a class="button" href="books.php">Manage Books</a><a class="button secondary" href="categories.php">Manage Categories</a><a class="button secondary" href="borrowers.php">Manage Borrowers</a><a class="button secondary" href="transactions.php">Borrow a Book</a><a class="button secondary" href="returns.php">Record a Return</a><a class="button secondary" href="reports.php">View Reports</a></div></section>';

echo '<section class="panel"><div class="section-heading"><div><h2>Overdue books</h2><p class="muted">Books that have passed their due date and are not yet returned.</p></div></div>';
$stmt = $pdo->query("SELECT t.transaction_id, b.title, br.full_name, t.due_date FROM borrow_transactions t JOIN books b ON b.book_id=t.book_id JOIN borrowers br ON br.borrower_id=t.borrower_id WHERE t.status='Borrowed' AND t.due_date<CURDATE() ORDER BY t.due_date");
$rows = $stmt->fetchAll();
if (!$rows) echo '<p class="empty-state">No overdue books. Great!</p>';
else {
    echo '<div class="table-wrap"><table><thead><tr><th>Transaction</th><th>Book</th><th>Borrower</th><th>Due date</th></tr></thead><tbody>';
    foreach ($rows as $r) echo '<tr><td>'.e($r['transaction_id']).'</td><td>'.e($r['title']).'</td><td>'.e($r['full_name']).'</td><td>'.e($r['due_date']).'</td></tr>';
    echo '</tbody></table></div>';
}
echo '</section>';
page_footer();
