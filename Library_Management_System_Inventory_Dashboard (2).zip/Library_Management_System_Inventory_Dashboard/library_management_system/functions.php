<?php
require_once __DIR__ . '/config.php';

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function redirect(string $url): never {
    header("Location: {$url}");
    exit;
}
function require_login(): void {
    if (empty($_SESSION['user_id'])) redirect('login.php');
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(403);
            exit('Invalid request token. Please go back and try again.');
        }
    }
}
function flash(string $message, string $type = 'success'): void {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        echo '<div class="alert ' . e($f['type']) . '">' . e($f['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}
function page_header(string $title): void {
    require_login();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . e($title) . ' | Library Management System</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="topbar"><div><strong>📚 Library Management System</strong><span class="small">Welcome, ' . e($_SESSION['full_name'] ?? 'User') . '</span></div>';
    echo '<nav><a href="index.php">Dashboard</a><a href="books.php">Books</a><a href="categories.php">Categories</a><a href="borrowers.php">Borrowers</a><a href="transactions.php">Borrowing</a><a href="returns.php">Returns</a><a href="reports.php">Reports</a><a href="logout.php">Logout</a></nav></header>';
    echo '<main class="container"><h1>' . e($title) . '</h1>';
    show_flash();
}
function page_footer(): void {
    echo '</main><footer>Library Management System · Advanced DBMS Project</footer><script src="assets/app.js"></script></body></html>';
}
function post_value(string $key, string $default = ''): string {
    return trim((string)($_POST[$key] ?? $default));
}
