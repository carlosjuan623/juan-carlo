<?php
require_once 'functions.php';
verify_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='save') {
        $id=(int)($_POST['book_id']??0); $total=max(0,(int)($_POST['total_copies']??0));
        $available=max(0,(int)($_POST['available_copies']??0));
        if ($available>$total) {flash('Available copies cannot be greater than total copies.','error');redirect('books.php');}
        $data=[post_value('isbn')?:null,post_value('title'),post_value('author'),post_value('publisher')?:null,post_value('publish_year')?:null,(int)$_POST['category_id'],$total,$available];
        if ($id) {$stmt=$pdo->prepare("UPDATE books SET isbn=?,title=?,author=?,publisher=?,publish_year=?,category_id=?,total_copies=?,available_copies=? WHERE book_id=?");$stmt->execute([...$data,$id]);flash('Book updated.');}
        else {$stmt=$pdo->prepare("INSERT INTO books(isbn,title,author,publisher,publish_year,category_id,total_copies,available_copies) VALUES(?,?,?,?,?,?,?,?)");$stmt->execute($data);flash('Book added.');}
    } elseif($action==='delete') {
        try {$stmt=$pdo->prepare("DELETE FROM books WHERE book_id=?");$stmt->execute([(int)$_POST['book_id']]);flash('Book deleted.');}
        catch(PDOException $e){flash('This book has transaction records and cannot be deleted.','error');}
    }
    redirect('books.php');
}
page_header('Book Management');
$edit=null;
if(isset($_GET['edit'])){$stmt=$pdo->prepare("SELECT * FROM books WHERE book_id=?");$stmt->execute([(int)$_GET['edit']]);$edit=$stmt->fetch();}
$cats=$pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();
echo '<section class="panel"><h2>'.($edit?'Edit book':'Add new book').'</h2>';
if(!$cats) echo '<p>Please add a category first in <a href="categories.php">Categories</a>.</p>';
else {
echo '<form method="post" class="form-grid"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="save"><input type="hidden" name="book_id" value="'.e($edit['book_id']??'').'">';
$fields=['isbn'=>'ISBN','title'=>'Book title','author'=>'Author','publisher'=>'Publisher','publish_year'=>'Publish year','total_copies'=>'Total copies','available_copies'=>'Available copies'];
foreach($fields as $key=>$label){$type=in_array($key,['publish_year','total_copies','available_copies'])?'number':'text';$required=in_array($key,['title','author','total_copies','available_copies'])?'required':'';echo '<label>'.e($label).'<input type="'.$type.'" name="'.e($key).'" value="'.e($edit[$key]??(in_array($key,['total_copies','available_copies'])?'1':'')).'" '.$required.'></label>';}
echo '<label>Category<select name="category_id" required>';foreach($cats as $c){$sel=(isset($edit['category_id'])&&(int)$edit['category_id']===(int)$c['category_id'])?'selected':'';echo '<option value="'.e($c['category_id']).'" '.$sel.'>'.e($c['category_name']).'</option>';}echo '</select></label><div><button>Save book</button> <a class="button secondary" href="books.php">Clear</a></div></form>';
}
echo '</section>';
$q=trim($_GET['q']??'');$stmt=$pdo->prepare("SELECT b.*,c.category_name FROM books b JOIN categories c ON c.category_id=b.category_id WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? ORDER BY b.title");$like="%{$q}%";$stmt->execute([$like,$like,$like]);$rows=$stmt->fetchAll();
echo '<section class="panel"><h2>Book list</h2><form method="get" class="search"><input name="q" placeholder="Search title, author, ISBN" value="'.e($q).'"><button>Search</button></form><div class="table-wrap"><table><tr><th>Title</th><th>Author</th><th>Category</th><th>Copies</th><th>Action</th></tr>';
foreach($rows as $r){echo '<tr><td>'.e($r['title']).'<br><span class="small">'.e($r['isbn']).'</span></td><td>'.e($r['author']).'</td><td>'.e($r['category_name']).'</td><td>'.e($r['available_copies']).' / '.e($r['total_copies']).' available</td><td><a href="books.php?edit='.e($r['book_id']).'">Edit</a> <form class="inline" method="post" onsubmit="return confirmDelete()"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="delete"><input type="hidden" name="book_id" value="'.e($r['book_id']).'"><button class="link danger-text">Delete</button></form></td></tr>';}
echo '</table></div></section>';page_footer();
