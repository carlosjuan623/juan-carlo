<?php
require_once 'functions.php';
verify_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $book=(int)($_POST['book_id']??0);$borrower=(int)($_POST['borrower_id']??0);$borrowDate=post_value('borrow_date');$dueDate=post_value('due_date');
 try{
  $pdo->beginTransaction();
  $s=$pdo->prepare("SELECT available_copies FROM books WHERE book_id=? FOR UPDATE");$s->execute([$book]);$b=$s->fetch();
  if(!$b || (int)$b['available_copies']<1) throw new Exception('No available copy of this book.');
  if(!$borrower || !$borrowDate || !$dueDate || $dueDate<$borrowDate) throw new Exception('Check borrower and dates. Due date must not be before borrow date.');
  $s=$pdo->prepare("INSERT INTO borrow_transactions(book_id,borrower_id,borrowed_by,borrow_date,due_date) VALUES(?,?,?,?,?)");
  $s->execute([$book,$borrower,$_SESSION['user_id'],$borrowDate,$dueDate]);
  $s=$pdo->prepare("UPDATE books SET available_copies=available_copies-1 WHERE book_id=?");$s->execute([$book]);
  $pdo->commit();flash('Borrowing transaction recorded.');
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash($e->getMessage(),'error');}
 redirect('transactions.php');
}
page_header('Borrowing Transactions');
$books=$pdo->query("SELECT book_id,title,available_copies FROM books WHERE available_copies>0 ORDER BY title")->fetchAll();
$borrowers=$pdo->query("SELECT borrower_id,full_name FROM borrowers ORDER BY full_name")->fetchAll();
echo '<section class="panel"><h2>Record a borrowed book</h2>';
if(!$books||!$borrowers)echo '<p>Add at least one book with available copies and one borrower first.</p>';
else{echo '<form method="post" class="form-grid"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><label>Book<select name="book_id" required>';foreach($books as $b)echo '<option value="'.e($b['book_id']).'">'.e($b['title']).' ('.e($b['available_copies']).' available)</option>';echo '</select></label><label>Borrower<select name="borrower_id" required>';foreach($borrowers as $b)echo '<option value="'.e($b['borrower_id']).'">'.e($b['full_name']).'</option>';echo '</select></label><label>Borrow date<input type="date" name="borrow_date" value="'.date('Y-m-d').'" required></label><label>Due date<input type="date" name="due_date" value="'.date('Y-m-d',strtotime('+7 days')).'" required></label><div><button>Save borrowing</button></div></form>';}
echo '</section>';
$rows=$pdo->query("SELECT t.*,b.title,br.full_name FROM borrow_transactions t JOIN books b ON b.book_id=t.book_id JOIN borrowers br ON br.borrower_id=t.borrower_id ORDER BY t.transaction_id DESC")->fetchAll();
echo '<section class="panel"><h2>Transaction history</h2><div class="table-wrap"><table><tr><th>ID</th><th>Book</th><th>Borrower</th><th>Borrowed</th><th>Due</th><th>Status</th></tr>';
foreach($rows as $r)echo '<tr><td>'.e($r['transaction_id']).'</td><td>'.e($r['title']).'</td><td>'.e($r['full_name']).'</td><td>'.e($r['borrow_date']).'</td><td>'.e($r['due_date']).'</td><td>'.e($r['status']).($r['status']==='Borrowed'&&$r['due_date']<date('Y-m-d')?' (Overdue)':'').'</td></tr>';
echo '</table></div></section>';page_footer();
