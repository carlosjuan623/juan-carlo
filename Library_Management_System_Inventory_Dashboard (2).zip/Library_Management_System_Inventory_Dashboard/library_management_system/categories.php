<?php
require_once 'functions.php';
verify_csrf();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add' && post_value('category_name')) {
        $stmt=$pdo->prepare("INSERT INTO categories(category_name,description) VALUES(?,?)");
        try {$stmt->execute([post_value('category_name'),post_value('description')]); flash('Category added.');}
        catch(PDOException $e){flash('Could not add category. It may already exist.','error');}
    } elseif ($action === 'delete') {
        try {$stmt=$pdo->prepare("DELETE FROM categories WHERE category_id=?");$stmt->execute([(int)$_POST['category_id']]);flash('Category deleted.');}
        catch(PDOException $e){flash('This category is used by a book and cannot be deleted.','error');}
    }
    redirect('categories.php');
}
page_header('Book Categories');
echo '<section class="panel"><h2>Add category</h2><form method="post" class="form-grid"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="add"><label>Category name<input name="category_name" required></label><label>Description<input name="description"></label><div><button>Add category</button></div></form></section>';
$rows=$pdo->query("SELECT c.*,COUNT(b.book_id) book_count FROM categories c LEFT JOIN books b ON b.category_id=c.category_id GROUP BY c.category_id ORDER BY c.category_name")->fetchAll();
echo '<section class="panel"><h2>Categories</h2><div class="table-wrap"><table><tr><th>Name</th><th>Description</th><th>Books</th><th>Action</th></tr>';
foreach($rows as $r){echo '<tr><td>'.e($r['category_name']).'</td><td>'.e($r['description']).'</td><td>'.e($r['book_count']).'</td><td><form method="post" onsubmit="return confirmDelete()"><input type="hidden" name="csrf_token" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="delete"><input type="hidden" name="category_id" value="'.e($r['category_id']).'"><button class="danger small-btn">Delete</button></form></td></tr>';}
echo '</table></div></section>'; page_footer();
